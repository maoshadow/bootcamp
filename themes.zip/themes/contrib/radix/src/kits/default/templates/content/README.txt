Place node template files here.
