Place menu template files here.
