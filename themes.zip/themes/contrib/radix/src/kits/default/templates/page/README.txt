Place page and region template files here.
